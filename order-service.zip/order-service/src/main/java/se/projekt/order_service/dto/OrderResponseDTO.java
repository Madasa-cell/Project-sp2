package se.projekt.order_service.dto;

import java.time.LocalDateTime;

public class OrderResponseDTO {
    private Long id;
    private Long customerId;
    private Long restaurantId;
    private String items;
    private double totalPrice;
    private LocalDateTime orderDate;

    // Getters and setters...
}
