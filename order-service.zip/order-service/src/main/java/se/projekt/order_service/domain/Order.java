package se.projekt.order_service.domain;

import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
public class Order {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private Long customerId;
    private Long restaurantId;
    private String items; // JSON eller komma-separerad
    private double totalPrice;

    private LocalDateTime orderDate;

    // Getters and setters...
}
