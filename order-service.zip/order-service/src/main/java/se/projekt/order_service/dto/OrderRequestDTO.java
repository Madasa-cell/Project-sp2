package se.projekt.order_service.dto;

public class OrderRequestDTO {
    private Long customerId;
    private Long restaurantId;
    private String items;

    // Getters and setters...
}
